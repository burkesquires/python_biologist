This example shows the daily record, average, and actual temperatures for three
cities (Austin, Boston, Seattle) in 2015. The default view includes a discrete
graph of the temperatures, but a smoothed representation can be selected.

To run the script, execute:

    bokeh serve --show weather/
