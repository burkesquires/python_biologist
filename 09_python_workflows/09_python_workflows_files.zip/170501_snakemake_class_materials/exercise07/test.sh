#! ./rnaseq

hisat2 --version
which salmon
