Example slide decks:

- [Jupyter Intro -_Background](https://reproducible-science-curriculum.github.io/introduction-RR-Jupyter/slides/Jupyter_Intro_Background.slides.html#/)
- [Working with Notebooks](https://reproducible-science-curriculum.github.io/introduction-RR-Jupyter/slides/Workshop%20slides%20-%20using%20the%20notebooks.slides.html#/)
