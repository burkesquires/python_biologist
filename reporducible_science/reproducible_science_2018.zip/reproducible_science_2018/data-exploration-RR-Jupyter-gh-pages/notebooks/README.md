# data-exploration-RR-Jupyter
The lesson for this section is in the .ipynb file above. Use the student version to challenge yourself. = )

See the Intro Lesson for instructions on installing the Jupyter Notebook and to learn basic operations in the Notebook. 
