Contact info
------------
Rumple Stiltskin
rumple@stiltskin.com
01/01/2000

Data Origin
-----------
This data is the gapminder dataset, originally collected and published in XXX, and retrieved from [1]. The dataset reflects population-level statistics about many countries spanning the last several decades.

The Excel (xlsx) file has been converted from tab-delimited text, with no modifications to the data.

[1] https://github.com/Reproducible-Science-Curriculum/data-exploration-RR-Jupyter/blob/master/gapminderDataFiveYear_superDirty.txt
