General Information
-------------------
Original data source: 00_raw/gapminderDataFiveYear_superDirty.txt
Modified with: Microsoft Excel

Modifications made to data
--------------------------
6,[B,D] - Adding NA
1,C - Spaces to underscores
1,D - Standardizing naming w/ underscores
[338,334,346-358],E - Correcting mis-spelled country names
[335-358],E - spaces to underscores, removing special characters