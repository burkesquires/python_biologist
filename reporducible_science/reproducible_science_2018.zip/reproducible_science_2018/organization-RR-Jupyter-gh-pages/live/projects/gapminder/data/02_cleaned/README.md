Modifications made to data
--------------------------
This is the same data in 01_cleaning. No modifications made.