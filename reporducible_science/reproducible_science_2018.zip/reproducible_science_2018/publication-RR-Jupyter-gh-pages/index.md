---
layout: lesson
root: .
permalink: index.html  # Is the only page that don't follow the partner /:path/index.html
---
FIXME: home page introduction

> ## Prerequisites
>
> FIXME
{: .prereq}
