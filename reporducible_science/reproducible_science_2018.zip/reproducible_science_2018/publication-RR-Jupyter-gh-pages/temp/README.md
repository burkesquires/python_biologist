# publication-RR-Jupyter
This repository contains the training materials for teaching 'Publication and sharing with Jupyter notebooks'. 

These lessons are part of a larger workshop on Reproducible Research using Jupyter Notebooks: https://reproducible-science-curriculum.github.io/rr-jupyter-workshop/. 

This lesson on publication can be broken down into four parts that can be taught independently or as a whole.
- Exporting the notebook - 30 minutes
- Documentation - 30 minutes
- Record level metadata - 35 minutes
- Publication - ?? minutes
