from setuptools import setup


raise Exception(
    """

    This file exists to set up the Github "Used By" counter properly and is not meant to be run.

    Please refer to ./packages/python/plotly/setup.py instead.
    """
)

setup(name="plotly")
