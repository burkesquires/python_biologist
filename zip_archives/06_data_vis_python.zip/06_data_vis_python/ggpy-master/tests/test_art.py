from ggplot import *


print ggplot(diamonds, aes('price')) + geom_now_its_art()
