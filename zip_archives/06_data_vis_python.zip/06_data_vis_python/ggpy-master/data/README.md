Datsets that are too big to inclue in the ggplot pypi package
