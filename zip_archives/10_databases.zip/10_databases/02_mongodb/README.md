# NOSQLDatabases
This Project is about accessing NOSQL databases (MongoDB,Cassendra and Neo4j ) in jupyter notebook and performing simple queries
