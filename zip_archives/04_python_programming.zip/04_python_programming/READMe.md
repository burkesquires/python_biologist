Python Programming for Scientists

Welcome! Please feel free to download this repository and learn to program in python!

f35b0dd44c361f54d1c0c37b5d65033aef0fb9a7
