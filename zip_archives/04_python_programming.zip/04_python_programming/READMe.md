Python Programming for Scientists


Welcome! Please feel free to download this repository and learn to program in python!