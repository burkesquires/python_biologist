import marimo

__generated_with = "0.16.5"
app = marimo.App()


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""# Introduction to the Python Programming Language""")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""<img align=center src="https://www.python.org/static/community_logos/python-logo-master-v3-TM.png">""")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(
        r"""
    ---
    - Author: R. Burke Squires
    - This presentation is part of the [__Python Programming for Biologists Series__](https://github.com/burkesquires/python_biologist)
    - Source: Includes material adapted from [Learn Python3 in Y Minutes](https://learnxinyminutes.com/docs/python3/)
    ---
    """
    )
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""## Writing a Python program to convert temperatures""")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(
        r"""
    In the notebook we will learn how to use the `python` programming language to write a program or script that converts temperatures between Fahrenheit to Celsius and back. As you may recall, Fahrenheit and centigrade are two temperature scales in use today. The Fahrenheit scale was developed by the German physicist Daniel Gabriel Fahrenheit. In the Fahrenheit scale, water freezes at 32 degrees and boils at 212 degrees. The centigrade scale, which is also called the Celsius scale, was developed by Swedish astronomer Andres Celsius. In the centigrade scale, water freezes at 0 degrees and boils at 100 degrees. 

    The formula to convert temperatures from degrees Fahrenheit to degrees Celsius is:

    __Fahrenheit to Celsius formula:__ $$°C = \frac{(°F - 32) 5}{9}$$ 

    or in plain English, from your existing temperature value subtract 32, then multiply by 5, then divide by 9.

    The centigrade to Fahrenheit conversion formula is:

    __Celsius to Fahrenheit formula:__ $$°F = \frac{°C 9}{5} + 32$$ 

    or in plain English, multiple by 9, then divide by 5, then add 32.
    """
    )
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(
        r"""
    In our example, we will assume that we have a temperatures measurement that we want to convert. Later in this tutorial we will extend the script to allow it to work on any number of temperature measurements.

    To begin with, lets us think about what steps we would use if we were converting a temperature manually:

    ### Steps to convert a temperature

    1. 
    1. 
    1.
    1.
    """
    )
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(
        r"""
    We can now convert that to pseudocode:

    ### Pseudocode

    1. Read in a temperature
    1. Determine existing scale
    1. Convert temperature to new scale
    1. Print new temperature
    """
    )
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""---""")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(
        r"""
    ## Contents
    - Data Types
    - Variables
    - Operators (Math with Python)
    - Functions
    - List
    - Loops
    - Strings
    - Files
    - Conditionals
    - Dictionaries
    - Modules
    """
    )
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(
        r"""
    ## Data Types in `python`

    Integers or `int`s are typed just as you would expect; no symbols or extra characters are needed.
    ```python
    x = 100
    ```
    Floating point number (decimal numbers) or `float`s just add a decimal
    ```python
    y = 32.0
    ```
    """
    )
    return


@app.cell
def _():
    # Practice by typing the code above:
    x = 100
    y = 32.0
    return


@app.cell
def _():
    # magic command not supported in marimo; please file an issue to add support
    # %whos 
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(
        r"""
    Other data types include:

    Strings (`str`), which we will look at in more depth later. Here we have a string of four characters, which we would understand are four nucleotides.
    ```python
    seq = 'ATCG'   
    ```
    A List (or array) is a set of numbers, strings, etc or any combination there of.
    ```python
    nt = ['A', 'C', 'G', 'T']
    ```
    """
    )
    return


@app.cell
def _():
    # Practice by typing the code above:
    seq = "ATCG"
    nt = ['A', 'C', 'G', "T"]
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(
        r"""
    > #### Do You Want To Know More About..._Primitive Data Types_   (Adapted from [source](https://learnxinyminutes.com/docs/python3/))
    > 
    > You have numbers:
    > ```python
    > 3 # => 3
    > ```
    > Math is what you would expect:
    > ```python
    > 1 + 1   # => 2
    > 8 - 1   # => 7
    > 10 * 2  # => 20
    > 35 / 5  # => 7.0
    > ```
    > Boolean values are primitives (Note: the capitalization)
    > ```python
    > True
    > False
    > ```
    > Negate with `not`
    > ```python
    > not True   # => False
    > not False  # => True
    > ```
    > Boolean Operators
    > Note "and" and "or" are case-sensitive
    > ```python
    > True and False  # => False
    > False or True   # => True
    > ```
    > True and False are actually 1 and 0 but with different keywords
    > ```python
    > True + True # => 2
    > True * 8    # => 8
    > False - 5   # => -5
    > ```
    > Comparison operators look at the numerical value of True and False
    > ```python
    > 0 == False  # => True
    > 1 == True   # => True
    > 2 == True   # => False
    > -5 != False # => True
    > ```
    > Using boolean logical operators on ints casts them to booleans for evaluation, but their non-cast value is returned
    > Don't mix up with bool(ints) and bitwise and/or (&, |)
    > ```python
    > bool(0)     # => False
    > bool(4)     # => True
    > bool(-6)    # => True
    > 0 and 2     # => 0
    > -5 or 0     # => -5
    > ```
    """
    )
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""---""")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""## Variables""")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(
        r"""
    - Unlike other programming languages, in `python` you do not need to use a command or keyword to declare a variable
    - A variable is created the moment you first assign a value to it
    - Variables _should_ have meaningful names and must start with a letter
    """
    )
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(
        r"""
    ```python
    temp = 32.0

    f_temp = 32.0

    temperature_fahrenheit = 32.0
    ```
    """
    )
    return


@app.cell
def _():
    # Practice by typing the code above:
    f_temp = 32.0
    c_temp = 0
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(
        r"""
    > #### Do You Want To Know More About... _Variables_
    > There are no declarations, only assignments.
    > The convention is to use `lower_case_with_underscores`
    > ```python
    > some_var = 5
    > some_var  # => 5
    > ```
    >
    >
    > Accessing a previously unassigned variable is an exception.
    > See Control Flow to learn more about exception handling.
    > ```python
    > some_unknown_var  # Raises a NameError
    > ```
    >
    > if can be used as an expression
    > Equivalent of C's '?:' ternary operator
    > ```python
    > "yahoo!" if 3 > 2 else 2  # => "yahoo!"
    > ```
    """
    )
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""---""")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""## Doing Math with `python`""")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(
        r"""
    To do math in `python`, we type the equation out using the `+`, `-`, `*`, `/` operators.

    Recall, that the formula to convert temperatures in Celsius to Fahrenheit is:

    $$°F = \frac{ °C  x  9 }{5} + 32$$ 


    As an example, if we want to convert 40.0 degrees Celsius to Fahrenheit we would write:

    $$°F = \frac{ 40°C  x  9 }{5} + 32$$

    Which is equivalent to:

    40 X 9 / 5 + 32

    What should the answer be?

    Did you get 104.0?
    """
    )
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(
        r"""
    ## Arithmetic Operators in `Python`

    Arithmetic operators are used with numeric values to perform common mathematical operations:

    |Operator|Name|Example|
    |---|---|---|
    |+|Addition|x + y|
    |-|Subtraction|x - y|
    |*|Multiplication|x * y|
    |/|Division|x / y|
    |%|Modulus|x % y|
    |**|Exponentiation|x ** y| 
    |//|Floor division|x // y|
    """
    )
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(
        r"""
    To convert 40.0 degrees Celsius to Fahrenheit we would type:
    
    ```python
    40.0 * (9 / 5) + 32
    ```
    """
    )
    return


@app.cell
def _():
    # Practice by typing the code above:

    40 * 9 / 5 + 32
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(
        r"""
    What answer did you get? Did you get 104.0?

    What happens if you do not add the parenthesis?
    """
    )
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(
        r"""
    > #### Do You Want To Know More About..._Math_
    > 
    > Result of integer division truncated down both for positive and negative.
    > ```python
    > 5 // 3       # => 1
    > 5.0 // 3.0   # => 1.0 # works on floats too
    > -5 // 3      # => -2
    > -5.0 // 3.0  # => -2.0
    > ```
    > The result of division is always a float
    > ```python
    > 10.0 / 3  # => 3.3333333333333335
    > ```
    > Modulo operation
    > ```python
    > 7 % 3  # => 1
    > ```
    > Exponentiation (x**y, x to the yth power)
    > ```python
    > 2**3  # => 8
    > ```
    > Enforce precedence with parentheses
    > ```python
    > (1 + 3) * 2  # => 8
    > ```
    """
    )
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""---""")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""## Writing Functions""")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(
        r"""
    Beginning with the formula we just saw, what parts of this change each time to calculate a conversion?
    ```python
    40.0 * (9 / 5) + 32
    ```
    The `40.0` temperature changes, right.

    If we replace the temperature with a variable, `temp`, then the equation becomes:
    ```python
    temp * (9 / 5) + 32
    ```
    but how do we set the value of `temp`?

    ```python
    temp = 40.0
    temp * (9 / 5) + 32
    ```
    If you run this script do you get the same answer as before? Try it:
    """
    )
    return


@app.cell
def _():
    # Practice by typing the code above:
    c_temp_1 = 40.0
    c_temp_1 * (9 / 5) + 32
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(
        r"""
    So we have a formula that allows us to change the starting temperature but it will only output to the screen or standard out. That will not do! :-)

    Lets change our code to save our converted temperature to a new variable.
    ```python
    temp = 10
    new_temp = temp * 9 / 5 + 32
    ```
    So now, we can access our `new_temp` to get our new temperature.
    """
    )
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(
        r"""
    Now, we can add a line of code to define a python function. 

    The `def` or define keyword in python starts a function definition and the line ends with a colon or `:`.

    ```python
    def convert_c_to_f(temp):
        new_temp = temp * 9 / 5 + 32
        return new_temp
    ```
    Note that we have to define a function name, `convert_c_to_f` and provide one parameter `temp`.

    We also add the `return` keyword to return the value of the new temperature.
    """
    )
    return


@app.cell
def _():
    # Practice by typing the code above:
    c_temp_2 = 50

    def convert_c_to_f(input_temp):
        return input_temp * (9 / 5) + 32
    print(convert_c_to_f(c_temp_2))
    return (convert_c_to_f,)


@app.cell
def _(convert_c_to_f):
    temp_list = [0, 32, 100]
    new_temps = []

    for temp in temp_list:
        new_temps.append(convert_c_to_f(temp))

    new_temps
    return


@app.cell
def _():
    def convert_c_to_f_1(input_temp):
        return input_temp * (9 / 5) + 32

    def convert_f_to_c(input_temp):
        return input_temp - 32 * 5 / 9
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(
        r"""
    Now recall that defining a function is only half of the task. We also have to _call_ the function to execute it.

    To _call_ our function we write:

    ```python
    c_temp = 40.0
    f_temp = convert_c_to_f(c_temp)
    print(f_temp)
    ```

    Note that the function code must be run in the Jupyter Notebook before you _call_ if if they are in two difference cells, as they are here.
    """
    )
    return


@app.cell
def _():
    # Practice by typing the code above:
    c_temp_3 = 10
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(
        r"""
    __Discussion__

    - Why not just copy and paste the original formula or the formula with our variable?
    - We could also skip the step of saving an intermediate variable `new_temp` and return it directly. Why might we NOT want to do this?
    """
    )
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(
        r"""
    Now we will enhance the function a little to be more explicit and rename our input temperature as well as _cast_ or convert our input temperature to a floating point number. 

    We will also add a new function for Fahrenheit to Celsius conversion.

    Here are the two functions, with an additional step to convert the incoming temperature to a floating point number:

    ```python
    def convert_c_to_f(c_temp):
        f_temp = (float(c_temp) * 9 / 5 + 32)
        return f_temp

    def convert_f_to_c(f_temp):
        c_temp = (float(f_temp) - 32) * 5 / 9
        return c_temp
    ```
    """
    )
    return


@app.cell
def _():
    # Practice by typing the code above:
    def convert_c_to_f_2(c_temp):
        f_temp = float(c_temp) * 9 / 5 + 32
        return f_temp

    def convert_f_to_c_1(f_temp):
        c_temp = (float(f_temp) - 32) * 5 / 9
        return c_temp
    convert_c_to_f_2(input())
    return convert_c_to_f_2, convert_f_to_c_1


@app.cell
def _():
    float("10")
    return


@app.cell
def _():
    # magic command not supported in marimo; please file an issue to add support
    # %whos 
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(
        r"""
    > __Do You Want To Know More About...*Functions*__
    > 
    > Use "def" to create new functions
    > ```python
    > def add(x, y):
    >     print("x is {} and y is {}".format(x, y))
    >     return x + y  # Return values with a return statement
    > ```
    >Calling functions with parameters
    > ```python
    > add(5, 6)  # => prints out "x is 5 and y is 6" and returns 11
    > ```
    >Another way to call functions is with keyword arguments
    > ```python
    > add(y=6, x=5)  # Keyword arguments can arrive in any order.
    > ```
    >You can define functions that take a variable number of positional arguments
    > ```python
    > def varargs(*args):
    >     return args
    > varargs(1, 2, 3)  # => (1, 2, 3)
    > ```
    > ```python
    > all_the_args(1, 2, a=3, b=4) prints:
    >     (1, 2)
    >     {"a": 3, "b": 4}
    > ```
    > When calling functions, you can do the opposite of args/kwargs!

    > Use * to expand tuples and use ** to expand kwargs.
    > ```python
    > args = (1, 2, 3, 4)
    > kwargs = {"a": 3, "b": 4}
    > all_the_args(*args)            # equivalent to all_the_args(1, 2, 3, 4)
    > ```
    > Returning multiple values (with tuple assignments)
    > ```python
    > def swap(x, y):
    >     return y, x 
    > ```
    > Return multiple values as a tuple without the parenthesis. 
    > (Note: parenthesis have been excluded but can be included)
    > ```python
    > x = 1
    > y = 2
    > x, y = swap(x, y)     # => x = 2, y = 1
    > (x, y) = swap(x,y)    # Again parenthesis have been excluded but can be included.
    > ```
    """
    )
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""---""")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""## Testing our Code""")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""Testing our code gives an opportunity to prove to ourselves (and anyone else) that our code works as expected.""")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(
        r"""
    ```python
    import unittest

    assert(convert_c_to_f(32.0) == 89.6)
    assert(convert_f_to_c(212.0) == 100.0)
    ```
    No errors means to code works as expected.

    Try changing any number above and rerun the cell to test again.
    """
    )
    return


@app.cell
def _(convert_c_to_f_2, convert_f_to_c_1):
    import unittest
    assert convert_c_to_f_2(32.0) == 89.5
    assert convert_f_to_c_1(212.0) == 100.0
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""---""")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""## Lists""")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""Above we used our new function to convert one temperature at a time. Next, we are going to learn about `lists` and how we can use them to do many temperature conversions at once.""")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(
        r"""
    In `python` lists are created using the square brackets `[`, `]` like this:
    ```python
    f_temps = [0.0, 32.0, 100.0, 212.0]
    ```

    To convert our entire list of temperatures, we will look at loops in a moment but before we do that, we can look at how to convert individual elements of our list. 

    To access the first element of the list, we write this:
    ```python
    f_temps[0]
    ```

    This demonstrates to use that `python` is a zero-based language, meaning that indicies start with 0 instead of 1.
    """
    )
    return


@app.cell
def _():
    # Practice by typing the code above:

    f_temps = [0.0, 23.0, 100, 212.0]
    return (f_temps,)


@app.cell(hide_code=True)
def _(mo):
    mo.md(
        r"""
    We can also compute how many temperatures are in our list using:
    ```python
    len(f_temps)
    ```
    """
    )
    return


@app.cell
def _(f_temps):
    # Practice by typing the code above:

    len(f_temps)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(
        r"""
    > __Do You Want To Know More About...*Functions*__
    > 
    > Lists store sequences
    > ```python
    > li = []
    > ```
    > You can start with a prefilled list
    > ```python
    > other_li = [4, 5, 6]
    > ```
    > Add stuff to the end of a list with append
    > ```python
    > li.append(1)    # li is now [1]
    > li.append(2)    # li is now [1, 2]
    > li.append(4)    # li is now [1, 2, 4]
    > li.append(3)    # li is now [1, 2, 4, 3]
    > ```
    > Remove from the end with pop
    > ```python
    > li.pop()        # => 3 and li is now [1, 2, 4]
    > ```
    > Let's put it back
    > ```python
    > li.append(3)    # li is now [1, 2, 4, 3] again.
    > ```
    > Access a list like you would any array
    > ```python
    > li[0]   # => 1
    > ```
    > Look at the last element
    > ```python
    > li[-1]  # => 3
    > ```
    > Looking out of bounds is an IndexError
    > ```python
    > li[4]  # Raises an IndexError
    > ```
    > You can look at ranges with slice syntax.
    > The start index is included, the end index is not
    > (It's a closed/open range for you mathy types.)
    > ```python
    > li[1:3]   # => [2, 4]
    > ```
    > Omit the beginning and return the list
    > ```python
    > li[2:]    # => [4, 3]
    > ```
    > Omit the end and return the list
    > ```python
    > li[:3]    # => [1, 2, 4]
    > ```
    > Select every second entry
    > ```python
    > li[::2]   # =>[1, 4]
    > ```
    > Return a reversed copy of the list
    > ```python
    > li[::-1]  # => [3, 4, 2, 1]
    > ```
    > Use any combination of these to make advanced slices
    > ```python
    > li[start:end:step]
    > ```
    > Make a one layer deep copy using slices
    > ```python
    > li2 = li[:]  # => li2 = [1, 2, 4, 3] but (li2 is li) will result in false.
    > ```
    > Remove arbitrary elements from a list with "del"
    > ```python
    > del li[2]  # li is now [1, 2, 3]
    > ```
    > Remove first occurrence of a value
    > ```python
    > li.remove(2)  # li is now [1, 3]
    > li.remove(2)  # Raises a ValueError as 2 is not in the list
    > ```
    > Insert an element at a specific index
    > ```python
    > li.insert(1, 2)  # li is now [1, 2, 3] again
    > ```
    > Get the index of the first item found matching the argument
    > ```python
    > li.index(2)  # => 1
    > li.index(4)  # Raises a ValueError as 4 is not in the list
    > ```
    > You can add lists
    > Note: values for li and for other_li are not modified.
    > ```python
    > li + other_li  # => [1, 2, 3, 4, 5, 6]
    > ```
    > Concatenate lists with "extend()"
    > ```python
    > li.extend(other_li)  # Now li is [1, 2, 3, 4, 5, 6]
    > ```
    > Check for existence in a list with "in"
    > ```python
    > 1 in li  # => True
    > ```
    """
    )
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""---""")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""## Loops""")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(
        r"""
    As we saw above, following the opening of a file in python, there is a very simple `loop` implementation, shown below:
    ```python
    for line in f:
        print(line)
    ```

    Here we see that there is a keyword `for` to start the loop, followed by a variable to refer to each of the indiVIdual elements being looped over, the `in` keYword, and finally, the object being interacted or looped over. In this case `f`.
    """
    )
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(
        r"""
    ```python
    with open("f_temps.txt") as f:
    
        for line in f:
        
            temp = float(line)
            new_temp = convert_f_to_c(temp)
        
            print("f{temp} deg. F = {new_temp} deg. C")
    ```
    """
    )
    return


@app.cell
def _(convert_f_to_c_1, f_temps):
    # Practice by typing the code above:
    for temp_1 in f_temps:
        temp_1 = float(temp_1)
        new_temp = convert_f_to_c_1(temp_1)
        print(f'{temp_1:2.3f} deg. F = {new_temp:2.2f} deg. C')
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(
        r"""
    > __Do You Want To Know More About...*Loops*__
    >
    > For loops iterate over lists prints:
    >    dog is a mammal
    >    cat is a mammal
    >    mouse is a mammal
    > ```python
    > for animal in ["dog", "cat", "mouse"]:
    >     print("{} is a mammal".format(animal))
    > ```
    > `range(number)` returns an iterable of numbers from zero to the given number prints:
    > 0
    > 1
    > 2
    > 3
    > ```python
    > for i in range(4):
    >     print(i)
    > ```
    > `range(lower, upper)` returns an iterable of numbers from the lower number to the upper number prints:
    >   4
    >   5
    >   6
    >   7
    > ```python
    > for i in range(4, 8):
    >     print(i)
    > ```
    >`range(lower, upper, step)` returns an iterable of numbers from the lower number to the upper number, while incrementing by step. If step is not indicated, the default value is 1. prints:
    >    4
    >    6
    > ```python
    > for i in range(4, 8, 2):
    >     print(i)
    > ```
    > While loops go until a condition is no longer met prints:
    >    0
    >    1
    >    2
    >    3
    > ```python
    > x = 0
    > while x < 4:
    >     print(x)
    >     x += 1  # Shorthand for x = x + 1
    > ```
    """
    )
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""---""")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""## String Formatting""")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""Did you notice that the last line of the `with` code above ended with an odd statement using `f`? That is THE current _pythonic_ way of formatting a string, known as `formatted string literals`, or `f-strings`. Use curly brackets "{}" as place holder for variables, with the variable inside. You can even space out the formatting so that the COLUMNS line up. Try this code out:""")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(
        r"""
    ```python
    with open("f_temps.txt") as f:
    
        for line in f:
        
            temp = float(line)
            new_temp = convert_f_to_c(temp)
        
            print("f{temp:8.2f} deg. F = {new_temp:8.2f} deg. C".format(temp, new_temp))
    ```
    """
    )
    return


@app.cell
def _(convert_f_to_c_1):
    # Practice by typing the code above:
    with open('f_temps.txt') as f:
        for line in f:
            temp_2 = float(line)
            new_temp_1 = convert_f_to_c_1(temp_2)
            print(f'{temp_2:6.2f} deg. F = {new_temp_1:8.2f} deg. C')  #.format(temp, new_temp))
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(
        r"""
    > __Do You Want To Know More About...*Strings*__
    > 
    > Strings are created with " or '
    > ```python
    > "This is a string."
    > 'This is also a string.'
    > ```
    > Strings can be added too! But try not to do this.
    > ```python
    > "Hello " + "world!"  # => "Hello world!"
    > ```
    > String literals (but not variables) can be concatenated without using '+'
    > ```python
    > "Hello " "world!"    # => "Hello world!"
    > ```
    > A string can be treated like a list of characters
    > ```python
    > "This is a string"[0]  # => 'T'
    > ```
    > You can find the length of a string
    > ```python
    > len("This is a string")  # => 16
    > ```
    > .format can be used to format strings, like this:
    > ```python
    > "{} can be {}".format("Strings", "interpolated")  # => "Strings can be interpolated"
    > ```
    > You can repeat the formatting arguments to save some typing.
    > ```python
    > "{0} be nimble, {0} be quick, {0} jump over the {1}".format("Jack", "candle stick") # => "Jack be nimble, Jack be quick, Jack jump over the candle stick"
    > ```
    > You can use keywords if you don't want to count.
    > ```python
    > "{name} wants to eat {food}".format(name="Bob", food="lasagna")  # => "Bob wants to eat lasagna"
    > ```
    > If your Python 3 code also needs to run on Python 2.5 and below, you can also still use the old style of formatting:
    > ```python
    > "%s can be %s the %s way" % ("Strings", "interpolated", "old")  # => "Strings can be interpolated the old way"
    > ```
    > You can also format using f-strings or formatted string literals (in Python 3.6+)
    > ```python
    > name = "Reiko"
    > f"She said her name is {name}." # => "She said her name is Reiko"
    > ```
    > You can basically put any Python statement inside the braces and it will be output in the string.
    > ```python
    > f"{name} is {len(name)} characters long."
    > ```
    """
    )
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""---""")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""## Working with Files""")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(
        r"""
    Now that we have functions to compute the changes of temperatures from one scale to another, we can calculate the changes of many temperatures at one time.

    To demonstrate how to convert many temperatures at one time, we will use some simple text files to store our temperatures.

    To create a temperature files we __could__:
        1. Open a text editor, type in our text, save the file and return to our python program OR
        2. Write a short python script to save some data to a file

    __BUT__ with Jupyter notebook we can use come Jupyter _magic_ to create that file for us while we stay right here in the Jupyter notebook.

    To do this we use the `%%writefile` Jupyter magic command, add the file name after it (with extension), then the information we want in the file in the rest of the cell.

    Run each cell to create the file.
    """
    )
    return


@app.cell
def _():
    # magic command not supported in marimo; please file an issue to add support
    # %%writefile c_temps.txt
    # 0.0
    # 32.0
    # 100.0
    # 212.0
    return


@app.cell
def _():
    # magic command not supported in marimo; please file an issue to add support
    # %%writefile f_temps.txt
    # 0.0
    # 32.0
    # 100.0
    return


app._unparsable_cell(
    r"""
    !ls
    !ls /
    """,
    name="_"
)


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""## Files""")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""Now we want to open one of the files, read the temperates line-by-line and convert each temperature, printing it to the screen.""")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(
        r"""
    To read data from a file we will use the `open()` function built into `python`.

    We will also use the _pythonic_ way of accessing files BY using the `with` keyword, as we see below.
    ```python
    with open("f_temps.txt") as f:
    
        for line in f:
        
            print(line)
    ```
    """
    )
    return


@app.cell
def _():
    # Practice by typing the code above:
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(
        r"""
    > __Do You Want To Know More About...*With*__
    > 
    > "The `with` statement simplifies exception handling by encapsulating common preparation and cleanup tasks in so-called context managers. The `with` statement is used to wrap the execution of a block with methods defined by a context manager. This allows common try…except…finally usage patterns to be encapsulated for convenient reuse." [Source](http://lofic.github.io/tips/python-with_statement.html)
    >
    > "A good way to see `with` used effectively is by looking at examples in the Python standard library. A well-known example involves the open() function:
    > ```python
    > with open('hello.txt', 'w') as f:
    >     f.write('hello, world!')
    > ```
    > Opening files using the with statement is generally recommended because it ensures that open file descriptors are closed automatically after program execution leaves the context of the with statement. Internally, the above code sample translates to something like this:
    > ```python
    > f = open('hello.txt', 'w')
    > try:
    >     f.write('hello, world')
    > finally:
    >     f.close()
    > ```
    > [Source](https://dbader.org/blog/python-context-managers-and-with-statement)
    """
    )
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""The above code reads the temperature from a file and prints them out, BUT we have not yet converted them. We will look at loops, which we see above, and in the discussion of the loop we will use out temperature conversion functions.""")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(
        r"""
    __Discussion__:
    - What would happen if we did not have a function to convert the temperature but wanted to convert many temperatures?
    """
    )
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""---""")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""## If Statements & Conditionals""")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(
        r"""
    Python supports the usual logical conditions from mathematics:

    |Conditional|Name|Example|
    |---|---|---|
    |==|Equals|a == b|
    |!=|Not Equals|a != b|
    |<|Less than|a < b|
    |<=|Less than or equal to|a <= b|
    |>|Greater than|a > b|
    |>=|Greater than or equal to|a >= b|

    These conditions can be used in several ways, most commonly in "if statements" and loops.

    An "if statement" is written by using the `if` keyword, followed by a conditional statement and a colon ":", as shown below. The line immediately following the colon MUST be indented for `python` to know what code or statements are part of the `if` statement, etc. In an effort to make `python` code more readable, `python` replaces the nested `if` statements with the `elif` or `else...if` keyword. This allows you to test many conditions while not getting lost in nested logic statements.
    """
    )
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(
        r"""
    ```python
    temps = 'f'

    # We have copied these functions from above

    def convert_c_to_f(c_temp):
        f_temp = (float(c_temp) * 9 / 5 + 32)
        return f_temp

    def convert_f_to_c(f_temp):
        c_temp = (float(f_temp) - 32) * 5 / 9
        return c_temp

    # New code starts here

    def convert_temp(scale, conversion_function):
    
        opposite_scale = {"C": "F", "F": "C"}
    
        file_name = "{}_temps.txt".format(scale)
    
        with open(file_name) as f:
        
            for line in f:

                temp = float(line)
            
                new_temp = conversion_function(temp)

                print("{:8.2f} deg. {} = {:8.2f} deg. {}".format(temp, 
                                                                 str.upper(scale), 
                                                                 new_temp, 
                                                                 opposite_scale[str.upper(scale)]))
    
    if temps == 'c':

        convert_temp("c", convert_c_to_f)

    elif temps == 'f':

        convert_temp("f", convert_f_to_c)
    ```
    """
    )
    return


@app.cell
def _():
    # Practice by typing the code above:
    temps = 'c'

    def convert_c_to_f_3(c_temp):
    # We have copied these functions from above
        f_temp = float(c_temp) * 9 / 5 + 32
        return f_temp

    def convert_f_to_c_2(f_temp):
        c_temp = (float(f_temp) - 32) * 5 / 9
        return c_temp

    def convert_temp(scale, conversion_function):
        opposite_scale = {'C': 'F', 'F': 'C'}
    # New code starts here
        file_name = '{}_temps.txt'.format(scale)
        with open(file_name) as f:
            for line in f:
                temp = float(line)
                new_temp = conversion_function(temp)
                print('{:8.2f} deg. {} = {:8.2f} deg. {}'.format(temp, str.upper(scale), new_temp, opposite_scale[str.upper(scale)]))
    if temps == 'c':
        convert_temp('c', convert_c_to_f_3)
    elif temps == 'f':
        convert_temp('f', convert_f_to_c_2)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(
        r"""
    > __Do You Want To Know More About...*If Statements*__
    >
    > Indentation is significant in Python! Convention is to use four spaces, not tabs. This prints "some_var is smaller than 10"
    > ```python
    > if some_var > 10:
    >     print("some_var is totally bigger than 10.")
    > elif some_var < 10:    # This elif clause is optional.
    >     print("some_var is smaller than 10.")
    > else:                  # This is optional too.
    >     print("some_var is indeed 10.")
    > ```
    """
    )
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(
        r"""
    __Try This...__

    - Try using the `input()` function above, instead of hard coding a temperature scale, to request input from a user.
    """
    )
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""---""")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""## Dictionaries""")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(
        r"""
    Dictionaries are data structures with key, value pairs. Each key must be unique and the values can be repeated. The real strength of dictionaries is being able to find values quickly from a large set of keys.

    One can use dictionary to record metadata or comments about some temperatures

    We can create an empty dictionary using the statement:
    ```python
    important_temps = {}
    ```

    Then we can add a few important temps to our dictionary:

    ```python
    important_temps[32] = "Water freezes (if F scale)"
    important_temps[0] = "Water freezes (if C scale)"
    important_temps[212] = "Water boils (if F scale)"
    important_temps[100] = "Water boils (if C scale)"

    important_temps[32]
    ```
    """
    )
    return


@app.cell
def _():
    # Practice by typing the code above:
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(
        r"""
    Next, try entering a number or temperature that is __NOT__ in the dictionary. Try:
    ```python
    important_temps[31]
    ```
    """
    )
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(
        r"""
    > __Do You Want To Know More About...*Dictionaries*__
    >
    > Dictionaries store mappings from keys to values
    > ```python
    > empty_dict = {}
    > ```
    > Here is a prefilled dictionary
    > ```python
    > filled_dict = {"one": 1, "two": 2, "three": 3}
    > ```
    > Note keys for dictionaries have to be immutable types. This is to ensure that
    > the key can be converted to a constant hash value for quick look-ups.
    > Immutable types include ints, floats, strings, tuples.
    > ```python
    > invalid_dict = {[1,2,3]: "123"}  # => Raises a TypeError: unhashable type: 'list'
    > valid_dict = {(1,2,3):[1,2,3]}   # Values can be of any type, however.
    > ```
    > Look up values with []
    > ```python
    > filled_dict["one"]  # => 1
    > ```
    > Get all keys as an iterable with "keys()". We need to wrap the call in list() to turn it into a list. We'll talk about those later.  Note - for Python versions <3.7, dictionary key ordering is not guaranteed. Your results might not match the example below exactly. However, as of Python 3.7, dictionary items maintain the order at which they are inserted into the dictionary.
    > ```python
    > list(filled_dict.keys())  # => ["three", "two", "one"] in Python <3.7
    > list(filled_dict.keys())  # => ["one", "two", "three"] in Python 3.7+
    > ```
    > Get all values as an iterable with "values()". Once again we need to wrap it in list() to get it out of the iterable. Note - Same as above regarding key ordering.
    > ```python
    > list(filled_dict.values())  # => [3, 2, 1]  in Python <3.7
    > list(filled_dict.values())  # => [1, 2, 3] in Python 3.7+
    > ```
    > Check for existence of keys in a dictionary with "in"
    > ```python
    > "one" in filled_dict  # => True
    > 1 in filled_dict      # => False
    > ```
    > Looking up a non-existing key is a KeyError
    > ```python
    > filled_dict["four"]  # KeyError
    > ```
    > Use "get()" method to avoid the KeyError
    > ```python
    > filled_dict.get("one")      # => 1
    > filled_dict.get("four")     # => None
    > ```
    > The get method supports a default argument when the value is missing
    > ```python
    > filled_dict.get("one", 4)   # => 1
    > filled_dict.get("four", 4)  # => 4
    > ```
    > "setdefault()" inserts into a dictionary only if the given key isn't present
    > ```python
    > filled_dict.setdefault("five", 5)  # filled_dict["five"] is set to 5
    > filled_dict.setdefault("five", 6)  # filled_dict["five"] is still 5
    > ```
    > Adding to a dictionary
    > ```python
    > filled_dict.update({"four":4})  # => {"one": 1, "two": 2, "three": 3, "four": 4}
    > filled_dict["four"] = 4         # another way to add to dict
    > ```
    > Remove keys from a dictionary with del
    > ```python
    > del filled_dict["one"]  # Removes the key "one" from filled dict
    > ```
    > From Python 3.5 you can also use the additional unpacking options
    > ```python
    > {'a': 1, **{'b': 2}}  # => {'a': 1, 'b': 2}
    > {'a': 1, **{'a': 2}}  # => {'a': 2}
    > ```
    """
    )
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(
        r"""
    A better illustration of dictionaries, but not related to our temperature theme, is the example below. Here we use three `for` loops to create a dictionary of all possible DNA triples or codons. Then we could the frequency of each codon in the DNA sequence provided. This gives a better illustration of how we do not want to manually setup all 64 options but dictionaries enable us to search instantly for the frequency of any of the 64 options.

    ```python
    dna = "AATGATCGATCGTACGCTGAAATGATCGATCGTACGCTGAAATGATCGATCGTACGCTGAAATGATCGATCGTACGCTGAAATGATCGATCGTACGCTGA"

    counts = {}

    for base1 in ['A', 'T', 'G', 'C']:
        for base2 in ['A', 'T', 'G', 'C']:
            for base3 in ['A', 'T', 'G', 'C']:
                trinucleotide = base1 + base2 + base3
                count = dna.count(trinucleotide)
                counts[trinucleotide] = count
            
    counts["AAA"]
    ```
    """
    )
    return


@app.cell
def _():
    # Practice by typing the code above:

    dna = "AATGATCGATCGTACGCTGAAATGATCGATCGTACGCTGAAATGATCGATCGTACGCTGAAATGATCGATCGTACGCTGAAATGATCGATCGTACGCTGA"

    counts = {}

    for base1 in ['A', 'T', 'G', 'C']:
        for base2 in ['A', 'T', 'G', 'C']:
            for base3 in ['A', 'T', 'G', 'C']:
                trinucleotide = base1 + base2 + base3
                count = dna.count(trinucleotide)
                counts[trinucleotide] = count
            
    counts["AAA"]
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""Do you want to see this code will run step-by-step? Click [here](https://pythontutor.com/visualize.html#code=dna%20%3D%20%22AATGATCGATCGTACGCTGAAATGATCGATCGTACGCTGAAATGATCGATCGTACGCTGAAATGATCGATCGTACGCTGAAATGATCGATCGTACGCTGA%22%0A%0Acounts%20%3D%20%7B%7D%0A%0Afor%20base1%20in%20%5B'A',%20'T',%20'G',%20'C'%5D%3A%0A%20%20%20%20for%20base2%20in%20%5B'A',%20'T',%20'G',%20'C'%5D%3A%0A%20%20%20%20%20%20%20%20for%20base3%20in%20%5B'A',%20'T',%20'G',%20'C'%5D%3A%0A%20%20%20%20%20%20%20%20%20%20%20%20trinucleotide%20%3D%20base1%20%2B%20base2%20%2B%20base3%0A%20%20%20%20%20%20%20%20%20%20%20%20count%20%3D%20dna.count%28trinucleotide%29%0A%20%20%20%20%20%20%20%20%20%20%20%20counts%5Btrinucleotide%5D%20%3D%20count%0A%20%20%20%20%20%20%20%20%20%20%20%20%0Acounts%5B%22AAA%22%5D&cumulative=false&curInstr=300&heapPrimitives=nevernest&mode=display&origin=opt-frontend.js&py=3&rawInputLstJSON=%5B%5D&textReferences=false)""")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""---""")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""## Modules and Imports""")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(
        r"""
    One of the many reasons `python` is popular is because it hosts a large standard library of available functions or methods for programmers to use, but also because of the extensive community that has created thousands of `python` packages for anyone to use.

    These packages offer many features but most importantly they are tested (in most cases).

    To use a package from the standard library or somewhere else, we must `import` the package so that `python` knows where to find the methods we want to use. In an example below, we will save our temperature conversion functions to a file and import them to use them.

    We will rename the functions slightly as proof that we are importing our functions and not just using the ones from above.

    Run the `code` cell below to save our functions to a module.
    """
    )
    return


@app.cell
def _():
    # magic command not supported in marimo; please file an issue to add support
    # %%writefile temp_converter.py
    # def convert_temp_c_to_f(c_temp):
    #     f_temp = (float(c_temp) * 9 / 5 + 32)
    #     return f_temp
    # 
    # def convert_temp_f_to_c(f_temp):
    #     c_temp = (float(f_temp) - 32) * 5 / 9
    #     return c_temp
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""Now we want to import our code and use it to campute temperature conversions.""")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(
        r"""
    ```python
    import temp_converter

    temp_converter.convert_temp_c_to_f(100)
    ```
    """
    )
    return


@app.cell
def _():
    # Practice by typing the code above:

    import temp_converter

    temp_converter.convert_temp_f_to_c(100)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(
        r"""
    > __Do You Want To Know More About...*Modules*__
    >
    > You can import modules
    > ```python
    > import math
    > print(math.sqrt(16))  # => 4.0
    > ```
    > You can get specific functions from a module
    > ```python
    > from math import ceil, floor
    > print(ceil(3.7))   # => 4.0
    > print(floor(3.7))  # => 3.0
    > ```
    > You can import all functions from a module.
    > Warning: this is not recommended
    > ```python
    > from math import *
    > ```
    > You can shorten module names
    > ```python
    > import math as m
    > math.sqrt(16) == m.sqrt(16)  # => True
    > ```
    > Python modules are just ordinary Python files. You can write your own, and import them. The name of the module is the same as the name of the file. You can find out which functions and attributes are defined in a module.
    > ```python
    > import math
    > dir(math)
    > ```
    > If you have a Python script named math.py in the same folder as your current script, the file math.py will be loaded instead of the built-in Python module. This happens because the local folder has priority over Python's built-in libraries.
    """
    )
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(
        r"""
    Now extend the conversion to include Kelvin

    BUT instead of reusing the code for F to C or C to F conversions, use the functions above

        def convert_c_to_k(c_temp):
    
        def convert_k_to_c(k_temp):
    
        def convert_f_to_k(f_temp):
    
        def convert_k_to_f(k_temp):


    """
    )
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""---""")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""## Clean Up""")
    return


@app.cell
def _():
    # Clean up files that were created above:
    import os
    if os.path.exists("temp_converter.py"): os.remove("temp_converter.py")
    if os.path.exists("c_temps.txt"): os.remove("c_temps.txt")
    if os.path.exists("f_temps.txt"): os.remove("f_temps.txt")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""---""")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(
        r"""
    ### __To Learn More...__

    About reading and writing files using `python` check out these resources:

    - [Python 3 Documentation](https://docs.python.org/3/tutorial/inputoutput.html#reading-and-writing-files)
    - [REALPython Reading and Writing CSV Files in Python Tutorial](https://realpython.com/python-csv/)
    """
    )
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(
        r"""
    ## Resources:

    - [Learn Python3 in Y Minutes](https://learnxinyminutes.com/docs/python3/)
    - [W3 School Python tutorial](https://www.w3schools.com/python/default.asp)

    """
    )
    return


@app.cell
def _():
    import marimo as mo
    return (mo,)


if __name__ == "__main__":
    app.run()
