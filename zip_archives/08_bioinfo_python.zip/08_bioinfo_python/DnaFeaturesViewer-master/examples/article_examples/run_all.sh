python3 0_download_the_plasmid.py
python3 A_linear_plot.py
python3 B_detail_plot.py
python3 C_circular_display.py
python3 D_display_with_gc_content.py
python3 E_cartoon_plot.py
python3 F_bokeh_plot.py
