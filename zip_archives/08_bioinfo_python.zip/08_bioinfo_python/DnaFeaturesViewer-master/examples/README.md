# Examples


**Development note:** to run all examples and generate all figures, run:

```bash
for f in *.py; do python3 "$f"; done
```