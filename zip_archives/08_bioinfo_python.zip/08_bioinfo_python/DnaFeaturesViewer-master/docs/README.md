This directory contains the sources of the documentation.

To be able to compile the source, install the dependencies with


    sudo pip install sphinx sphinx-press-theme numpydoc
